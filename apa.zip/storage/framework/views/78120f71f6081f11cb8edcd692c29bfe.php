<div class="d-flex align-items-start">
    <div class="container">
        <div style="text-align: center">
            <h1  href="<?php echo e(route('user.create')); ?>">Tambah user</h1>
        </div>
        <form method="POST" action="<?php echo e(route('user.store')); ?>">
            <?php echo csrf_field(); ?>   
            <div class="form-group">
                <label for="name">Nama</label>
                <input type="text" name="name" id="name" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="no_tlp">Nomor Telepon</label>
                <input type="text" name="no_tlp" id="no_tlp" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="tipe">Tipe</label>
                <select name="tipe" id="tipe" class="form-select" required>
                    <option selected>Masukan</option>
                    <option value="S">S</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <br>
            <div style="text-align: center;">
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            
        </form>
    </div>
</div><?php /**PATH C:\laragon\www\jucang_app\resources\views/form.blade.php ENDPATH**/ ?>